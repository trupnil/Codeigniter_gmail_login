-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2019 at 11:20 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `google_user`
--

CREATE TABLE `google_user` (
  `user_id` int(11) NOT NULL,
  `id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `picture` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `google_user`
--

INSERT INTO `google_user` (`user_id`, `id`, `email`, `password`, `picture`, `name`) VALUES
(1, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(2, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(3, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(4, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(5, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(6, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(7, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(8, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(9, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(10, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(11, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(12, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(13, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(14, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(15, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(16, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(17, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(18, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(19, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja'),
(20, '116764510766634024840', 'mr.dharmrajsinh@gmail.com', NULL, 'https://lh4.googleusercontent.com/-H9mN9W37pe0/AAAAAAAAAAI/AAAAAAAAAAc/Pk0fp1Wvr_k/photo.jpg', 'Dharmrajsinh Matroja');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `google_user`
--
ALTER TABLE `google_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `google_user`
--
ALTER TABLE `google_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
