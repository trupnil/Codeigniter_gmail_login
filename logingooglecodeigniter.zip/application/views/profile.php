<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	<img src="<?php echo $this->session->userdata('picture') ?>">
	<p> Name: <?php echo $this->session->userdata('name') ?> </p>
	<p> Name: <?php echo $this->session->userdata('name') ?> </p>
	<p> Name: <?php echo $this->session->userdata('name') ?> </p>
	<p> Name: <?php echo $this->session->userdata('name') ?> </p>s
</body>
</html>